#!/usr/bin/env python3
"""ROOTMASTER Windows companion: inspect ADB/Fastboot and guarded init_boot flash."""
import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

def run(command, timeout=30):
    try:
        p = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, str(exc)

def tool(name):
    path = shutil.which(name)
    if not path:
        raise SystemExit(f"{name} introuvable. Installe Android SDK Platform-Tools et ajoute son dossier au PATH.")
    return path

def doctor(_):
    print("ROOTMASTER Desktop — diagnostic")
    for name in ("adb", "fastboot"):
        path = shutil.which(name)
        print(f"[{'OK' if path else 'MANQUANT'}] {name}: {path or 'non trouvé'}")
    print("Python:", sys.version.split()[0])
    print("Conseil: utilise les Platform-Tools officiels Google.")

def device(_):
    adb = tool("adb")
    code, out = run([adb, "devices", "-l"])
    print(out.strip() or "Aucun appareil ADB.")
    if code:
        raise SystemExit(code)
    code, model = run([adb, "shell", "getprop", "ro.product.device"])
    code2, build = run([adb, "shell", "getprop", "ro.build.display.id"])
    code3, release = run([adb, "shell", "getprop", "ro.build.version.release"])
    print("Codename:", model.strip() or "inconnu")
    print("Build:", build.strip() or "inconnu")
    print("Android:", release.strip() or "inconnu")
    if model.strip() != "shiba":
        print("AVERTISSEMENT: ce n'est pas le codename Pixel 8 attendu (shiba).")

def fastboot_check(_):
    fb = tool("fastboot")
    code, product = run([fb, "getvar", "product"])
    code2, unlocked = run([fb, "getvar", "unlocked"])
    print("Produit:", product.strip())
    print("État bootloader:", unlocked.strip())
    if "shiba" not in product.lower():
        raise SystemExit("ARRÊT: produit Fastboot non reconnu comme Pixel 8 / shiba.")
    if not any(x in unlocked.lower() for x in ("unlocked: yes", "unlocked: true")):
        raise SystemExit("ARRÊT: bootloader non confirmé déverrouillé. Aucun flash effectué.")
    print("Contrôles préliminaires réussis. Aucun changement effectué.")

def flash_init_boot(args):
    fb = tool("fastboot")
    image = Path(args.image).expanduser().resolve()
    if not image.is_file():
        raise SystemExit(f"Image introuvable: {image}")
    digest = hashlib.sha256(image.read_bytes()).hexdigest()
    print("Image:", image)
    print("SHA-256:", digest)
    if digest.lower() != args.sha256.lower():
        raise SystemExit("ARRÊT: le SHA-256 ne correspond pas à la valeur fournie.")
    code, product = run([fb, "getvar", "product"])
    if "shiba" not in product.lower():
        raise SystemExit("ARRÊT: appareil non identifié comme Pixel 8 (shiba).")
    code, unlocked = run([fb, "getvar", "unlocked"])
    if not any(x in unlocked.lower() for x in ("unlocked: yes", "unlocked: true")):
        raise SystemExit("ARRÊT: bootloader non confirmé déverrouillé.")
    print("\nATTENTION: cette commande écrit init_boot. Une image incorrecte peut empêcher le démarrage.")
    print("Confirme que cette image a été patchée sur CE téléphone par Magisk et correspond au build installé.")
    confirmation = input("Tape exactement FLASH INIT_BOOT pour continuer: ")
    if confirmation != "FLASH INIT_BOOT":
        raise SystemExit("Annulé. Aucune écriture effectuée.")
    code, out = run([fb, "flash", "init_boot", str(image)], timeout=180)
    print(out)
    if code:
        raise SystemExit(f"Fastboot a échoué (code {code}). Ne relance pas à l'aveugle.")
    print("Flash terminé. Redémarrage demandé.")
    code, out = run([fb, "reboot"], timeout=60)
    print(out)
    if code:
        print("Le flash a réussi, mais le redémarrage automatique a échoué. Redémarre manuellement.")

def main():
    parser = argparse.ArgumentParser(description="ROOTMASTER Windows companion")
    sub = parser.add_subparsers(required=True)
    p = sub.add_parser("doctor", help="Vérifier les outils")
    p.set_defaults(func=doctor)
    p = sub.add_parser("device", help="Lire les informations via ADB")
    p.set_defaults(func=device)
    p = sub.add_parser("fastboot-check", help="Vérifier produit et bootloader")
    p.set_defaults(func=fastboot_check)
    p = sub.add_parser("flash-init-boot", help="Flasher une image Magisk validée")
    p.add_argument("--image", required=True, help="Chemin de l'image init_boot patchée")
    p.add_argument("--sha256", required=True, help="SHA-256 attendu de l'image")
    p.set_defaults(func=flash_init_boot)
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
