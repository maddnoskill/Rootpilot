package ca.rootmaster.app

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RootMasterApp() }
    }
}

@Composable
private fun RootMasterApp() {
    val isPixel8 = Build.MANUFACTURER.equals("Google", true) &&
        Build.DEVICE.equals("shiba", true)
    val androidVersion = Build.VERSION.RELEASE ?: "Inconnue"
    val sdk = Build.VERSION.SDK_INT
    val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Inconnue"
    var expanded by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("ROOTMASTER", style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold)
                        Text("Assistant root Android · version 0.1.0",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                ElevatedCard {
                    Column(Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Diagnostic de l'appareil",
                            style = MaterialTheme.typography.titleLarge)
                        InfoRow("Fabricant", Build.MANUFACTURER)
                        InfoRow("Modèle", Build.MODEL)
                        InfoRow("Nom appareil", Build.DEVICE)
                        InfoRow("Android", androidVersion)
                        InfoRow("API", sdk.toString())
                        InfoRow("Architecture", abi)
                        HorizontalDivider()
                        Text(
                            if (isPixel8) "Pixel 8 détecté" else "Appareil différent du Pixel 8",
                            color = if (isPixel8) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                ElevatedCard {
                    Column(Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("État du processus", style = MaterialTheme.typography.titleLarge)
                        Text("Diagnostic local seulement. Cette application ne peut pas " +
                            "déverrouiller le bootloader ni flasher une partition Android.")
                        Text("Partition cible à confirmer : init_boot",
                            fontWeight = FontWeight.SemiBold)
                        Text("Méthode : image stock exacte → patch Magisk sur le téléphone → " +
                            "vérification SHA-256 → Fastboot depuis Windows.")
                    }
                }
                Button(onClick = { expanded = !expanded },
                    modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Android, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Guide de préparation")
                }
                if (expanded) {
                    ElevatedCard {
                        Column(Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Avant toute installation",
                                style = MaterialTheme.typography.titleMedium)
                            Text("1. Sauvegarder toutes les données.")
                            Text("2. Vérifier que Déverrouillage OEM est disponible.")
                            Text("3. Relever le numéro de build exact.")
                            Text("4. Télécharger uniquement le firmware officiel correspondant.")
                            Text("5. Patcher l'image sur ce Pixel avec l'application Magisk officielle.")
                            Text("6. Utiliser le compagnon Windows pour vérifier l'appareil et l'image.")
                            Text("Le déverrouillage du bootloader efface normalement toutes les données.")
                        }
                    }
                }
                Text("ROOTMASTER n'exploite aucune faille et n'effectue aucun flash automatique.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}
